export default[
    {
        question:"Quanto é",
        answer:[
            {option:"3,"}
        ]
    }
]
